//import java.io.*;
//import java.util.*;
//import java.text.*;
//import java.math.*;
//import java.util.regex.*;
//
//import java.util.Scanner;
//
//// base class
//abstract class transport {
//    String transport_mode;
//    String from;
//    String destination;
//    int distance;
//
//    // using constructor
//    transport(String transport_mode, String from, String destination, int distance) {
//        this.transport_mode = transport_mode;
//        this.from = from;
//        this.destination = destination;
//        this.distance = distance;
//    }
//
//    // abstract method for displaying the cost
//    public abstract void display_cost();
//}
//
//// bus class inherits from transport
//class bus extends transport {
//    List<String> timings;
//
//    public bus(String transport_mode, String from, String destination, int distance) {
//        super(transport_mode, from, destination, distance);
//        timings = new ArrayList<>();
//    }
//
//    // to enter time slots
//    public void add_time_slot(String timing) {
//        timings.add(timing);
//    }
//
//    // to display available time slot for bus route
//    public void display_time_slot() {
//        System.out.println("the available slots for " + transport_mode + " are:");
//        for (String timing : timings) {
//            System.out.println(timing);
//        }
//    }
//
//    // total distance cost of fare
//    public void display_cost() {
//        System.out.println(distance + " km is distance and cost is rupees " + distance * 2);
//    }
//}
//
//// train class inherits from transport
//class train extends transport {
//    List<String> timings;
//
//    public train(String transport_mode, String from, String destination, int distance) {
//        super(transport_mode, from, destination, distance);
//        timings = new ArrayList<>();
//    }
//
//    // to enter time slots
//    public void add_time_slot(String timing) {
//        timings.add(timing);
//    }
//
//    // to display available time slot for train route
//    public void display_time_slot() {
//        System.out.println("the available slots for " + transport_mode + " are:");
//        for (String timing : timings) {
//            System.out.println(timing);
//        }
//    }
//
//    // total distance cost of fare
//    //since laying tracks in space is costly cost per KM of train is also costly
//    public void display_cost() {
//        System.out.println(distance + " km is distance and cost is rupees " + distance * 100);
//    }
//}
//
//// rocket class inherits from transport
//class rocket extends transport {
//    List<String> timings;
//
//    public rocket(String transport_mode, String from, String destination, int distance) {
//        super(transport_mode, from, destination, distance);
//        timings = new ArrayList<>();
//    }
//
//    // to enter time slots
//    public void add_time_slot(String timing) {
//        timings.add(timing);
//    }
//
//    // to display available time slot for rocket route
//    public void display_time_slot() {
//        System.out.println("the available slots for " + transport_mode + " are:");
//        for (String timing : timings) {
//            System.out.println(timing);
//        
//        }
//	
//    
//	}	//total distance cost of fair
//    public void display_cost()
//	{
//		
//		System.out.println(distance+" is distance and cost is rupees"+distance*10);	
//	}
//}
//
//public class TransportLogic
//{
//		public static void main(String[] args) {
//            Scanner obj=new Scanner(System.in);
//		    List<transport> transports = new ArrayList<>();
//
//		System.out.println("welcome to transport enquire system follow the steps below");
//		//used in switch case according to coustmour choice
//		
//	    System.out.println("to select destination");
//	    System.out.println("press 1: earth to venus");
//		System.out.println("press 2: earth to mars");
//		System.out.println("press 3: earth to jupiter");
//		System.out.println("press 4: Exit");
//
//		int choice =obj.nextInt();
//		System.out.println("to select transport mode");
//	    System.out.println("press 5: bus");
//		System.out.println("press 6: train");
//		System.out.println("press 7: rocket");
//		System.out.println("press 8: Exit the transport mode");
//		int choice1 =obj.nextInt();
//
//		switch (choice) {
//            case 1:
//                switch(choice1)
//				{
//					case 5:
//					bus bus1 = new bus("Bus 1", "earth", "venus",30);
//                    bus1.add_time_slot("8am");
//                    bus1.add_time_slot("12pm");
//                    bus1.add_time_slot("4pm");
//                    transports.add(bus1);
//					bus1.display_time_slot();
//					bus1.display_cost();
//					break;
//					case 6:
//					train train1 = new train("Train 1", "earth", "venus",30);
//                    train1.add_time_slot("7am");
//                    train1.add_time_slot("11am");
//                    train1.add_time_slot("3pm");
//                    transports.add(train1);
//					train1.display_time_slot();
//					train1.display_cost();
//					break;
//					case 7:
//					rocket rocket1 = new rocket("rocket 1", "earth", "venus",30);
//                    rocket1.add_time_slot("9am");
//                    rocket1.add_time_slot("1pm");
//                    rocket1.add_time_slot("5pm");
//                    transports.add(rocket1);
//					rocket1.display_time_slot();
//					rocket1.display_cost();
//					break;
//					case 8:
//					System.out.println("Exiting the transport mode");
//                    System.exit(0);
//					break;
//					default:
//                System.out.println("Invalid choice. Please select a valid option.");
//                break;
//				}
//                break;
//				
//            case 2:
//			switch(choice1)
//				{
//					case 5:
//					bus bus2 = new bus("Bus 2", "earth", "mars",50);
//                    bus2.add_time_slot("8am");
//                    bus2.add_time_slot("12pm");
//                    bus2.add_time_slot("4pm");
//                    transports.add(bus2);
//					bus2.display_time_slot();
//					bus2.display_cost();
//					break;
//					case 6:
//					train train2 = new train("Train 2", "earth", "mars",50);
//                    train2.add_time_slot("7am");
//                    train2.add_time_slot("11am");
//                    train2.add_time_slot("3pm");
//                    transports.add(train2);
//					train2.display_time_slot();
//					train2.display_cost();
//					break;
//					case 7:
//					rocket rocket2 = new rocket("rocket 2", "earth", "jupiter",50);
//                    rocket2.add_time_slot("9am");
//                    rocket2.add_time_slot("1pm");
//                    rocket2.add_time_slot("5pm");
//                    transports.add(rocket2);
//					rocket2.display_time_slot();
//					rocket2.display_cost();
//					break;
//					case 8:
//					System.out.println("Exiting the transport mode");
//                    System.exit(0);
//					break;
//					default:
//                System.out.println("Invalid choice. Please select a valid option.");
//                break;
//				}
//                
//                break;
//            case 3:
//			switch(choice1)
//				{
//					case 5:
//					bus bus3 = new bus("Bus 3", "earth", "jupiter",70);
//                    bus3.add_time_slot("8am");
//                    bus3.add_time_slot("12pm");
//                    bus3.add_time_slot("4pm");
//                    transports.add(bus3);
//					bus3.display_time_slot();
//					bus3.display_cost();
//					break;
//					case 6:
//					train train3 = new train("Train 3", "earth", "jupiter",70);
//                    train3.add_time_slot("7am");
//                    train3.add_time_slot("11am");
//                    train3.add_time_slot("3pm");
//                    transports.add(train3);
//					train3.display_time_slot();
//					train3.display_cost();
//					break;
//					case 7:
//					rocket rocket3 = new rocket("rocket 3", "earth", "jupiter",70);
//                    rocket3.add_time_slot("9am");
//                    rocket3.add_time_slot("1pm");
//                    rocket3.add_time_slot("5pm");
//                    transports.add(rocket3);
//					rocket3.display_time_slot();
//					rocket3.display_cost();
//					break;
//					case 8:
//					System.out.println("Exiting the transport mode");
//                    System.exit(0);
//					break;
//					default:
//                System.out.println("Invalid choice. Please select a valid option.");
//                break;
//				}
//                
//                break;
//            case 4:
//                System.out.println("Exiting the Transport Enquiry System");
//                System.exit(0);
//            default:
//                System.out.println("Invalid choice. Please select a valid option.");
//                break;
//        }
//}}