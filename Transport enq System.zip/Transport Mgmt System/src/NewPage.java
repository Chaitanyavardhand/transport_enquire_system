import javax.swing.*;  
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;  
  
//create NewPage class to create a new page on which user will navigate  
public class NewPage extends JFrame  implements ActionListener 
{  
    //constructor
	JButton b1;  
    JPanel newPanel;  
    JLabel mode, route;  
    JTextField  textField1, textField2,textField3; 
    NewPage()  
    {  
//        setDefaultCloseOperation(javax.swing.  
//        WindowConstants.DISPOSE_ON_CLOSE);  
//        setTitle("Welcome");  
//        setSize(400, 200); 
    	route = new JLabel();  
        route.setText("<html>Welcome to transport enquire system follow the steps to slect destination <br/>  press 1: earth to venus <br/>   press 2: earth to mars <br/>   press 3: earth jupiter <br/> press 4: exit </html>"); 
        textField1 = new JTextField(15);
        mode = new JLabel();  
        mode.setText("<html>to select transport mode <br/> press 5: bus <br/> press 6: train <br/> press 7: rocket <br/> press 8: Exit the transport mode </html>");
        //create text field to get username from the user  
        textField2 = new JTextField(15);
        b1 = new JButton("SUBMIT"); //set label to button  
        
        //create panel to put form elements  
        newPanel = new JPanel(new GridLayout(3, 1));  
        newPanel.add(route);    //set username label to panel  
        newPanel.add(textField1);   //set text field to panel  
        newPanel.add(mode);    //set password label to panel  
        newPanel.add(textField2);   //set text field to panel  
        newPanel.add(b1);           //set button to panel  
          
        //set border to panel   
        add(newPanel, BorderLayout.CENTER);  
          
        //perform action on button click   
        b1.addActionListener(this); 
        
    } 
    
    
  

public void actionPerformed(ActionEvent ae)     //pass action listener as a parameter  
{  
    String route = textField1.getText();        //get user entered username from the textField1  
    String mode = textField2.getText();        //get user entered pasword from the textField2  
 
    //check whether the credentials are authentic or not  
    //if authentic, navigate user to a new page  
          
       // create instance of the NewPage  
        NewPage2 page = new NewPage2(route,mode);  
          
        //make page visible to the user  
        page.setVisible(true);  
          
        //create a welcome label and set it to the new page  
       
 }} 

