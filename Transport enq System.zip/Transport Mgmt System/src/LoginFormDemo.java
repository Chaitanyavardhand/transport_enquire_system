//import required classes and packages  
import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;  
import java.lang.Exception;
import java.util.ArrayList;
import java.util.List;  
import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;
  
//create CreateLoginForm class to create login form  
//class extends JFrame to create a window where our component add  
//class implements ActionListener to perform an action on button click  
class CreateLoginForm extends JFrame implements ActionListener  
{  
    //initialize button, panel, label, and text field  
    JButton b1;  
    JPanel newPanel;  
    JLabel userLabel, passLabel;  
    final JTextField  textField1, textField2;  
      
    //calling constructor  
    CreateLoginForm()  
    {     
          
        //create label for username   
        userLabel = new JLabel();  
        userLabel.setText("Username");      //set label value for textField1  
          
        //create text field to get username from the user  
        textField1 = new JTextField(15);    //set length of the text  
  
        //create label for password  
        passLabel = new JLabel();  
        passLabel.setText("Password");      //set label value for textField2  
          
        //create text field to get password from the user  
        textField2 = new JPasswordField(15);    //set length for the password  
          
        //create submit button  
        b1 = new JButton("SUBMIT"); //set label to button  
          
        //create panel to put form elements  
        newPanel = new JPanel(new GridLayout(3, 1));  
        newPanel.add(userLabel);    //set username label to panel  
        newPanel.add(textField1);   //set text field to panel  
        newPanel.add(passLabel);    //set password label to panel  
        newPanel.add(textField2);   //set text field to panel  
        newPanel.add(b1);           //set button to panel  
          
        //set border to panel   
        add(newPanel, BorderLayout.CENTER);  
          
        //perform action on button click   
        b1.addActionListener(this);     //add action listener to button  
        setTitle("LOGIN FORM");         //set title to the login form  
    }  
      
    //define abstract method actionPerformed() which will be called on button click   
    public void actionPerformed(ActionEvent ae)     //pass action listener as a parameter  
    {  
        String userValue = textField1.getText();        //get user entered username from the textField1  
        String passValue = textField2.getText();        //get user entered pasword from the textField2  
          
        //check whether the credentials are authentic or not  
        if (userValue.equals("test1@gmail.com") && passValue.equals("test")) {  //if authentic, navigate user to a new page  
              
            //create instance of the NewPage  
            NewPage page = new NewPage();  
              
            //make page visible to the user  
            page.setVisible(true);  
        }   
              
            //create a welcome label and set it to the new page  
//            JLabel wel_label = new JLabel("<html>Welcome to transport enquire system follow the steps to slect destination <br/>  press 1: earth to venus <br/>   press 2: earth to mars <br/>   press 3: earth jupiter <br/> press 4: exit </html>"+userValue);  
//            page.getContentPane().add(wel_label);
//            
//		    List<transport> transports = new ArrayList<>();
//
//            int choice =2;
//    	
//    		wel_label = new JLabel("<html>to select transport mode <br/> press 5: bus <br/> press 6: train <br/> press 7: rocket <br/> press 8: Exit the transport mode </html>"+userValue);  
//            page.getContentPane().add(wel_label);
            
//    		int choice1 =2;
//
//    		switch (choice) {
//                case 1:
//                    switch(choice1)
//    				{
//    					case 5:
//    					bus bus1 = new bus("Bus 1", "earth", "venus",30);
//                        bus1.add_time_slot("8am");
//                        bus1.add_time_slot("12pm");
//                        bus1.add_time_slot("4pm");
//                        transports.add(bus1);
//    					bus1.display_time_slot();
//    					bus1.display_cost();
//    					break;
//    					case 6:
//    					train train1 = new train("Train 1", "earth", "venus",30);
//                        train1.add_time_slot("7am");
//                        train1.add_time_slot("11am");
//                        train1.add_time_slot("3pm");
//                        transports.add(train1);
//    					train1.display_time_slot();
//    					train1.display_cost();
//    					break;
//    					case 7:
//    					rocket rocket1 = new rocket("rocket 1", "earth", "venus",30);
//                        rocket1.add_time_slot("9am");
//                        rocket1.add_time_slot("1pm");
//                        rocket1.add_time_slot("5pm");
//                        transports.add(rocket1);
//    					rocket1.display_time_slot();
//    					rocket1.display_cost();
//    					break;
//    					case 8:
//    					System.out.println("Exiting the transport mode");
//                        System.exit(0);
//    					break;
//    					default:
//                    System.out.println("Invalid choice. Please select a valid option.");
//                    break;
//    				}
//                    break;
//    				
//                case 2:
//    			switch(choice1)
//    				{
//    					case 5:
//    					bus bus2 = new bus("Bus 2", "earth", "mars",50);
//                        bus2.add_time_slot("8am");
//                        bus2.add_time_slot("12pm");
//                        bus2.add_time_slot("4pm");
//                        transports.add(bus2);
//    					bus2.display_time_slot();
//    					bus2.display_cost();
//    					break;
//    					case 6:
//    					train train2 = new train("Train 2", "earth", "mars",50);
//                        train2.add_time_slot("7am");
//                        train2.add_time_slot("11am");
//                        train2.add_time_slot("3pm");
//                        transports.add(train2);
//    					train2.display_time_slot();
//    					train2.display_cost();
//    					break;
//    					case 7:
//    					rocket rocket2 = new rocket("rocket 2", "earth", "jupiter",50);
//                        rocket2.add_time_slot("9am");
//                        rocket2.add_time_slot("1pm");
//                        rocket2.add_time_slot("5pm");
//                        transports.add(rocket2);
//    					rocket2.display_time_slot();
//    					rocket2.display_cost();
//    					break;
//    					case 8:
//    					System.out.println("Exiting the transport mode");
//                        System.exit(0);
//    					break;
//    					default:
//                    System.out.println("Invalid choice. Please select a valid option.");
//                    break;
//    				}
//                    
//                    break;
//                case 3:
//    			switch(choice1)
//    				{
//    					case 5:
//    					bus bus3 = new bus("Bus 3", "earth", "jupiter",70);
//                        bus3.add_time_slot("8am");
//                        bus3.add_time_slot("12pm");
//                        bus3.add_time_slot("4pm");
//                        transports.add(bus3);
//    					bus3.display_time_slot();
//    					bus3.display_cost();
//    					break;
//    					case 6:
//    					train train3 = new train("Train 3", "earth", "jupiter",70);
//                        train3.add_time_slot("7am");
//                        train3.add_time_slot("11am");
//                        train3.add_time_slot("3pm");
//                        transports.add(train3);
//    					train3.display_time_slot();
//    					train3.display_cost();
//    					break;
//    					case 7:
//    					rocket rocket3 = new rocket("rocket 3", "earth", "jupiter",70);
//                        rocket3.add_time_slot("9am");
//                        rocket3.add_time_slot("1pm");
//                        rocket3.add_time_slot("5pm");
//                        transports.add(rocket3);
//    					rocket3.display_time_slot();
//    					rocket3.display_cost();
//    					break;
//    					case 8:
//    					System.out.println("Exiting the transport mode");
//                        System.exit(0);
//    					break;
//    					default:
//                    System.out.println("Invalid choice. Please select a valid option.");
//                    break;
//    				}
//                    
//                    break;
//                case 4:
//                    System.out.println("Exiting the Transport Enquiry System");
//                    System.exit(0);
//                default:
//                    System.out.println("Invalid choice. Please select a valid option.");
//                    break;
//            }
//        }  
//        else{  
//            //show error message  
//            System.out.println("Please enter valid username and password");  
//        }  
      
}}
//create the main class  
public class LoginFormDemo  
{  
    //main() method start  
    public static void main(String arg[])  
    {  
        try  
        {  
            //create instance of the CreateLoginForm  
            CreateLoginForm form = new CreateLoginForm();  
            form.setSize(300,100);  //set size of the frame  
            form.setVisible(true);  //make form visible to the user  
        }  
        catch(Exception e)  
        {     
            //handle exception   
            JOptionPane.showMessageDialog(null, e.getMessage());  
        }  
    }  
} 


