import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.*;    


public class NewPage2 extends JFrame {
	
	NewPage2(String route,String mode)  
    {  
//        setDefaultCloseOperation(javax.swing.  
//        WindowConstants.DISPOSE_ON_CLOSE);  
//        setTitle("Welcome");  
//        setSize(400, 200); 
		
		 JLabel displaycost = new JLabel(); 
		 JLabel timeslot = new JLabel(); 
		 JPanel newPanel;

	     
		  List<transport> transports = new ArrayList<>();		
			switch (Integer.parseInt(route)) {
	            case 1:
	            	System.out.print(route+"(((((((((("+mode);
	                switch(Integer.parseInt(mode))
					{
						case 5:
						bus bus1 = new bus("Bus 1", "earth", "venus",30);
	                    bus1.add_time_slot("8am");
	                    bus1.add_time_slot("12pm");
	                    bus1.add_time_slot("4pm");
	                    transports.add(bus1);
						timeslot.setText(bus1.display_time_slot());
						displaycost.setText(bus1.display_cost());
						System.out.print(route+"(((((((((("+mode);
						break;
						case 6:
						train train1 = new train("Train 1", "earth", "venus",30);
	                    train1.add_time_slot("7am");
	                    train1.add_time_slot("11am");
	                    train1.add_time_slot("3pm");
	                    transports.add(train1);
	                    timeslot.setText(train1.display_time_slot());
						displaycost.setText(train1.display_cost());
						break;
						case 7:
						rocket rocket1 = new rocket("rocket 1", "earth", "venus",30);
	                    rocket1.add_time_slot("9am");
	                    rocket1.add_time_slot("1pm");
	                    rocket1.add_time_slot("5pm");
	                    transports.add(rocket1);
	                    timeslot.setText(rocket1.display_time_slot());
						displaycost.setText(rocket1.display_cost());
						break;
						case 8:
							displaycost.setText("Exiting the transport mode");
	                    System.exit(0);
						break;
						default:
							displaycost.setText("Invalid choice. Please select a valid option.");
	                break;
					}
	                break;
					
	            case 2:
				switch(Integer.parseInt(route))
					{
						case 5:
						bus bus2 = new bus("Bus 2", "earth", "mars",50);
	                    bus2.add_time_slot("8am");
	                    bus2.add_time_slot("12pm");
	                    bus2.add_time_slot("4pm");
	                    transports.add(bus2);
	                    timeslot.setText(bus2.display_time_slot());
						displaycost.setText(bus2.display_cost());
						break;
						case 6:
						train train2 = new train("Train 2", "earth", "mars",50);
	                    train2.add_time_slot("7am");
	                    train2.add_time_slot("11am");
	                    train2.add_time_slot("3pm");
	                    transports.add(train2);
	                    timeslot.setText(train2.display_time_slot());
						displaycost.setText(train2.display_cost());
						break;
						case 7:
						rocket rocket2 = new rocket("rocket 2", "earth", "jupiter",50);
	                    rocket2.add_time_slot("9am");
	                    rocket2.add_time_slot("1pm");
	                    rocket2.add_time_slot("5pm");
	                    transports.add(rocket2);
	                    timeslot.setText(rocket2.display_time_slot());
						displaycost.setText(rocket2.display_cost());
						break;
						case 8:
							displaycost.setText("Exiting the transport mode");
	                    System.exit(0);
						break;
						default:
							displaycost.setText("Invalid choice. Please select a valid option.");
	                break;
					}
	                
	                break;
	            case 3:
				switch(Integer.parseInt(route))
					{
						case 5:
						bus bus3 = new bus("Bus 3", "earth", "jupiter",70);
	                    bus3.add_time_slot("8am");
	                    bus3.add_time_slot("12pm");
	                    bus3.add_time_slot("4pm");
	                    transports.add(bus3);
	                    timeslot.setText(bus3.display_time_slot());
						displaycost.setText(bus3.display_cost());
						break;
						case 6:
						train train3 = new train("Train 3", "earth", "jupiter",70);
	                    train3.add_time_slot("7am");
	                    train3.add_time_slot("11am");
	                    train3.add_time_slot("3pm");
	                    transports.add(train3);
	                    timeslot.setText(train3.display_time_slot());
	                    displaycost.setText(train3.display_cost());
						break;
						case 7:
						rocket rocket3 = new rocket("rocket 3", "earth", "jupiter",70);
	                    rocket3.add_time_slot("9am");
	                    rocket3.add_time_slot("1pm");
	                    rocket3.add_time_slot("5pm");
	                    transports.add(rocket3);
	                    timeslot.setText(rocket3.display_time_slot());
	                    displaycost.setText(rocket3.display_cost());
						break;
						case 8:
							displaycost.setText("Exiting the transport mode");
	                    System.exit(0);
						break;
						default:
							displaycost.setText("Invalid choice. Please select a valid option.");
	                break;
					}
	                
	                break;
	            case 4:
	            	displaycost.setText("Exiting the Transport Enquiry System");
	                System.exit(0);
	            default:
	            	displaycost.setText("Invalid choice. Please select a valid option.");
	                break;
	        }  
//    	route = new JLabel();  
//        route.setText("<html>Welcome to transport enquire system follow the steps to slect destination <br/>  press 1: earth to venus <br/>   press 2: earth to mars <br/>   press 3: earth jupiter <br/> press 4: exit </html>"); 
//        textField1 = new JTextField(15);
//        mode = new JLabel();  
//        mode.setText("<html>to select transport mode <br/> press 5: bus <br/> press 6: train <br/> press 7: rocket <br/> press 8: Exit the transport mode </html>");
//        //create text field to get username from the user  
//        textField2 = new JTextField(15);
//        b1 = new JButton("SUBMIT"); //set label to button  
        
        //create panel to put form elements
//        newPanel = new JPanel(new GridLayout(1, 1));  
//        newPanel.add(displaycost);    //set username label to panel  
//            //set password label to panel
//        newPanel.add(timeslot);
//        //set text field to panel  
////        newPanel.add(b1);           //set button to panel  
////          
////        //set border to panel   
//        add(newPanel, BorderLayout.BEFORE_LINE_BEGINS);  
//          
//        //perform action on button click   
//        b1.addActionListener(this); 
			
			JFrame f;    
		    f=new JFrame();    
		    String data[][]={ {displaycost.getText(),timeslot.getText()}};    
		    String column[]={"Time Slots","Cost"};         
		    JTable jt=new JTable(data,column);    
		    jt.setBounds(30,40,200,300);          
		    JScrollPane sp=new JScrollPane(jt);    
		    f.add(sp);          
		    f.setSize(300,400);    
		    f.setVisible(true);    
        
     
        
}
	
	
}




abstract class transport {
    String transport_mode;
    String from;
    String destination;
    int distance;

    // using constructor
    transport(String transport_mode, String from, String destination, int distance) {
        this.transport_mode = transport_mode;
        this.from = from;
        this.destination = destination;
        this.distance = distance;
    }

    // abstract method for displaying the cost
    public abstract String display_cost();
}

// bus class inherits from transport
class bus extends transport {
    List<String> timings;

    public bus(String transport_mode, String from, String destination, int distance) {
        super(transport_mode, from, destination, distance);
        timings = new ArrayList<>();
    }

    // to enter time slots
    public void add_time_slot(String timing) {
        timings.add(timing);
    }

    // to display available time slot for bus route
    public String display_time_slot() {
    	String s ="the available slots for " + transport_mode + " are:";
        for (String timing : timings) {
            s=s+timing+"  ";
        }
        return s;
    }

    // total distance cost of fare
    public String display_cost() {
        return (distance + " km is distance and cost is rupees " + distance * 2);
    }
}

// train class inherits from transport
class train extends transport {
    List<String> timings;

    public train(String transport_mode, String from, String destination, int distance) {
        super(transport_mode, from, destination, distance);
        timings = new ArrayList<>();
    }

    // to enter time slots
    public void add_time_slot(String timing) {
        timings.add(timing);
    }

    // to display available time slot for train route
    public String display_time_slot() {
    	String s ="the available slots for " + transport_mode + " are:";
        for (String timing : timings) {
            s=s+timing+"  ";
        }
        return s;
    }

    // total distance cost of fare
    //since laying tracks in space is costly cost per KM of train is also costly
    public String display_cost() {
        return (distance + " km is distance and cost is rupees " + distance * 100);
    }
}

// rocket class inherits from transport
class rocket extends transport {
    List<String> timings;

    public rocket(String transport_mode, String from, String destination, int distance) {
        super(transport_mode, from, destination, distance);
        timings = new ArrayList<>();
    }

    // to enter time slots
    public void add_time_slot(String timing) {
        timings.add(timing);
    }

    // to display available time slot for rocket route
    public String display_time_slot() {
    	String s ="the available slots for " + transport_mode + " are:";
        for (String timing : timings) {
            s=s+timing+"  ";
        }
        return s;
	
    
	}	//total distance cost of fair
    public String display_cost()
	{
		return (distance+" is distance and cost is rupees"+distance*10);	
	}
}



